<@php

namespace {namespace};

class {class}
{
    // public function custom_rule(): bool
    // {
    //     return true;
    // }
}
